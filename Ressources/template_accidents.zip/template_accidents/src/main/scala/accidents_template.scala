import org.apache.spark.{SparkConf, SparkContext}
import scala.Console.println

object accidents_template extends App{
  val sparkConf = new SparkConf().setAppName("graphXTP").setMaster("local[1]")
  val sc = new SparkContext(sparkConf)

  val ACCIDENTS_DATA_PATH = "PATH_TO_CARACTERISTICS_CSV_FILE" //download from https://www.kaggle.com/ahmedlahlou/accidents-in-france-from-2005-to-2016
  val USERS_DATA_FILE = "PATH_TO_USERS_CSV_FILE"

  val caract_rdd = sc.textFile(ACCIDENTS_DATA_PATH).map(row => row.split(','))
  val headerRow = caract_rdd.first()
  val caract_rdd_clean = caract_rdd.filter(row => row(0) != headerRow(0))

  val nbAccidents = caract_rdd_clean.count()
  println("Total number of accidents = " + nbAccidents)

  //Day with a minimum number of accidents in 2016
  val accidents_min_by_day = caract_rdd_clean.filter(accident => accident(1) == "16").
                                              groupBy(accident => "20" + accident(1)+ '/' + accident(2)+ '/' +accident(3)).
                                              sortBy(accidentsPerDay => accidentsPerDay._2.size, true)
  println("Day with a minimum number of accidents in 2016 is" + accidents_min_by_day.first()._1)

  //Day with a maximum number of accidents in 2016
  val accidents_max_by_day = caract_rdd_clean.filter(accident => accident(1) == "16").
                                              groupBy(accident => "20" + accident(1)+ '/' + accident(2)+ '/' +accident(3)).
                                              sortBy(accidentsPerDay => accidentsPerDay._2.size, false)
  println("Day with a maximum number of accidents in 2016 is" + accidents_max_by_day.first()._1)

  //Evolution of the number of accidents
  val accidents_per_year = caract_rdd_clean.groupBy(accident => accident(1)).
                                            map(accidents_per_year => (2000 + accidents_per_year._1.toInt, accidents_per_year._2.size)).
                                            sortBy(accidents_per_year => accidents_per_year._1).collect()

  accidents_per_year.take(10).foreach(accidents_per_year => println(accidents_per_year))

  //Driver, passenger and pedestrians
  val users_rdd = sc.textFile(USERS_DATA_FILE)
                    .map(row => row.split(','))

  val nbUsers = users_rdd.count()
  println("Total number of users = " + nbUsers)

  /*
    Evolution of the age of drivers who had an accident in function of time
    Creation of 2 RDDs for accidents and users
    Join on both RDDs on the column representing the number of an accident
    Map keep only the year, age of the user = (date of accident - birth date)
    Find the average based on these columns
  */

  val drivers_rdd = users_rdd.filter(user => user(2) == "1") //filter on category = 1 -> Driver
  val header_2 = drivers_rdd.first()
  val drivers_rdd_clean = drivers_rdd.filter(row => row(0) != header_2(0))
  val caract_toJoin_rdd = caract_rdd_clean.filter(row => row(1) != "NA").map(row => (row(0), row))
  val drivers_toJoin_rdd  = drivers_rdd_clean.filter(row => row(10) != "NA").map(row => (row(0), row))

  val join_rdd = caract_toJoin_rdd.join(drivers_toJoin_rdd)
  val avg_list = join_rdd.map(row => (2000 + row._2._1(1).toInt, (2000 + row._2._1(1).toInt - row._2._2(10).toInt, 1)))
                         .reduceByKey((rowA, rowB) => (rowA._1 + rowB._1, rowA._2 + rowB._2))
                         .map(row => (row._1, row._2._1/row._2._2)).sortBy(row => row._1)
  avg_list.take(15).foreach(row => println(row))
}

